export const environment = {
  production: true,
  apiUrl: 'http://backup.sendatrack.com/sendatrack-dev/public/api/',
};
