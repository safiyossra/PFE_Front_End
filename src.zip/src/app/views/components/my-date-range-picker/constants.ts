import * as es from 'date-fns/locale/es';
import * as en from 'date-fns/locale/en-US';

export const locales: any = {
  es,
  en,
};
