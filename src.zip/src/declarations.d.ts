declare module '@coreui/coreui/dist/js/coreui-utilities';
declare module '@coreui/coreui-plugin-chartjs-custom-tooltips';

declare module '*.json' {
  const value: any;
  export default value;
}

